import java.util.Arrays;

public class SelectionSortDemo {
    static void selectionSort(int[] a, boolean descending) {
        for (int i = 0; i < a.length - 1; i++) {
            int best = i;
            for (int j = i + 1; j < a.length; j++)
                if (descending ? a[j] > a[best] : a[j] < a[best]) best = j;
            int t = a[i]; a[i] = a[best]; a[best] = t;
        }
    }

    public static void main(String[] args) {
        // Scenario 1: Arrange students' marks low to high
        System.out.println("=== Scenario 1: Marks Ascending ===");
        int[] marks = {64, 25, 12, 22, 11};
        System.out.println("Before: " + Arrays.toString(marks));
        selectionSort(marks, false);
        System.out.println("After : " + Arrays.toString(marks));

        // Scenario 2: Cricket scores -> top scorer first (leaderboard)
        System.out.println("\n=== Scenario 2: Cricket Leaderboard ===");
        int[] runs = {45, 102, 67, 8, 89};
        System.out.println("Before: " + Arrays.toString(runs));
        selectionSort(runs, true);
        System.out.println("Top scorer: " + runs[0] + " runs");
        System.out.println("Leaderboard: " + Arrays.toString(runs));
    }
}
