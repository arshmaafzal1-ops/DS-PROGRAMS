public class StackArrayDemo {
    static class Stack {
        String[] data; int top = -1;
        Stack(int cap) { data = new String[cap]; }
        boolean isEmpty() { return top == -1; }
        boolean isFull() { return top == data.length - 1; }
        void push(String s) {
            if (isFull()) { System.out.println("Stack Overflow!"); return; }
            data[++top] = s;
        }
        String pop() {
            if (isEmpty()) { System.out.println("Stack Underflow!"); return null; }
            return data[top--];
        }
        String peek() { return isEmpty() ? null : data[top]; }
    }

    public static void main(String[] args) {
        // Scenario 1: Browser Back button
        System.out.println("=== Scenario 1: Browser Back Button ===");
        Stack history = new Stack(5);
        history.push("google.com");
        history.push("youtube.com");
        history.push("github.com");
        System.out.println("Current page: " + history.peek());
        System.out.println("Back pressed -> leaving " + history.pop());
        System.out.println("Current page: " + history.peek());

        // Scenario 2: Balanced brackets checker
        System.out.println("\n=== Scenario 2: Balanced Brackets ===");
        String[] tests = {"{[()]}", "{[(])}", "((()"};
        for (String exp : tests) {
            Stack st = new Stack(exp.length());
            boolean ok = true;
            for (char c : exp.toCharArray()) {
                if ("([{".indexOf(c) >= 0) st.push(String.valueOf(c));
                else {
                    if (st.isEmpty()) { ok = false; break; }
                    char o = st.pop().charAt(0);
                    if ("([{".indexOf(o) != ")]}".indexOf(c)) { ok = false; break; }
                }
            }
            if (!st.isEmpty()) ok = false;
            System.out.println(exp + " -> " + (ok ? "Balanced" : "Not balanced"));
        }
    }
}
