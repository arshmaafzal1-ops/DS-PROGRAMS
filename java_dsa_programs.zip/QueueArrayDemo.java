public class QueueArrayDemo {
    static class Queue {   // circular queue
        String[] data; int front = 0, rear = -1, size = 0;
        Queue(int cap) { data = new String[cap]; }
        boolean isEmpty() { return size == 0; }
        boolean isFull() { return size == data.length; }
        void enqueue(String s) {
            if (isFull()) { System.out.println("Queue Full! " + s + " cannot join."); return; }
            rear = (rear + 1) % data.length;
            data[rear] = s; size++;
        }
        String dequeue() {
            if (isEmpty()) { System.out.println("Queue Empty!"); return null; }
            String s = data[front];
            front = (front + 1) % data.length; size--;
            return s;
        }
        void display() {
            System.out.print("Queue: ");
            for (int i = 0, j = front; i < size; i++, j = (j + 1) % data.length) System.out.print(data[j] + " ");
            System.out.println();
        }
    }

    public static void main(String[] args) {
        // Scenario 1: Railway ticket counter (limited waiting space)
        System.out.println("=== Scenario 1: Ticket Counter ===");
        Queue counter = new Queue(3);
        counter.enqueue("Rahul");
        counter.enqueue("Priya");
        counter.enqueue("Aman");
        counter.enqueue("Neha");          // full
        counter.display();
        System.out.println("Serving: " + counter.dequeue());
        counter.enqueue("Neha");          // space freed (circular reuse)
        counter.display();

        // Scenario 2: Printer job queue (FIFO)
        System.out.println("\n=== Scenario 2: Printer Queue ===");
        Queue printer = new Queue(5);
        printer.enqueue("Resume.pdf");
        printer.enqueue("Report.docx");
        printer.enqueue("Photo.png");
        while (!printer.isEmpty()) System.out.println("Printing: " + printer.dequeue());
        printer.dequeue();
    }
}
