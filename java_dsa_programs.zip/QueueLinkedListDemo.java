public class QueueLinkedListDemo {
    static class Node { String data; Node next; Node(String d) { data = d; } }

    static class Queue {
        Node front, rear;
        boolean isEmpty() { return front == null; }
        void enqueue(String d) {
            Node n = new Node(d);
            if (rear == null) front = rear = n;
            else { rear.next = n; rear = n; }
        }
        String dequeue() {
            if (isEmpty()) { System.out.println("Queue Empty!"); return null; }
            String d = front.data; front = front.next;
            if (front == null) rear = null;
            return d;
        }
        void display() {
            System.out.print("Waiting: ");
            for (Node t = front; t != null; t = t.next) System.out.print(t.data + " ");
            System.out.println();
        }
    }

    public static void main(String[] args) {
        // Scenario 1: Hospital OPD token system
        System.out.println("=== Scenario 1: Hospital OPD Tokens ===");
        Queue opd = new Queue();
        opd.enqueue("Token 1 - Ramesh");
        opd.enqueue("Token 2 - Sita");
        opd.enqueue("Token 3 - Karan");
        opd.display();
        System.out.println("Doctor calls: " + opd.dequeue());
        opd.enqueue("Token 4 - Meera");
        opd.display();

        // Scenario 2: Customer care call queue
        System.out.println("\n=== Scenario 2: Customer Care Calls ===");
        Queue calls = new Queue();
        calls.enqueue("Caller: 98xxxx101 (Refund)");
        calls.enqueue("Caller: 97xxxx202 (Login issue)");
        while (!calls.isEmpty()) System.out.println("Agent attending -> " + calls.dequeue());
        calls.dequeue();
    }
}
