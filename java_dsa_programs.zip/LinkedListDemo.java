public class LinkedListDemo {
    static class Node { String data; Node next; Node(String d) { data = d; } }

    static class SinglyList {
        Node head;
        void addFirst(String d) { Node n = new Node(d); n.next = head; head = n; }
        void addLast(String d) {
            Node n = new Node(d);
            if (head == null) { head = n; return; }
            Node t = head; while (t.next != null) t = t.next;
            t.next = n;
        }
        boolean delete(String d) {
            if (head == null) return false;
            if (head.data.equals(d)) { head = head.next; return true; }
            Node t = head;
            while (t.next != null && !t.next.data.equals(d)) t = t.next;
            if (t.next == null) return false;
            t.next = t.next.next; return true;
        }
        boolean search(String d) { for (Node t = head; t != null; t = t.next) if (t.data.equals(d)) return true; return false; }
        void reverse() {
            Node prev = null, cur = head;
            while (cur != null) { Node nx = cur.next; cur.next = prev; prev = cur; cur = nx; }
            head = prev;
        }
        void display() {
            for (Node t = head; t != null; t = t.next) System.out.print(t.data + " -> ");
            System.out.println("null");
        }
    }

    public static void main(String[] args) {
        // Scenario 1: Music playlist
        System.out.println("=== Scenario 1: Music Playlist ===");
        SinglyList playlist = new SinglyList();
        playlist.addLast("Kesariya");
        playlist.addLast("Tum Hi Ho");
        playlist.addLast("Apna Bana Le");
        playlist.addFirst("Chaiyya Chaiyya");   // play next
        playlist.display();
        System.out.println("Remove 'Tum Hi Ho': " + playlist.delete("Tum Hi Ho"));
        playlist.display();
        System.out.println("Is 'Kesariya' in playlist? " + playlist.search("Kesariya"));

        // Scenario 2: Train compartments
        System.out.println("\n=== Scenario 2: Train Compartments ===");
        SinglyList train = new SinglyList();
        train.addLast("Engine");
        train.addLast("S1");
        train.addLast("S2");
        train.addLast("Guard");
        train.display();
        train.addFirst("Extra Engine");         // attach at front
        train.display();
        train.reverse();                         // train runs in opposite direction
        System.out.print("After reversing: ");
        train.display();
    }
}
