import java.util.Arrays;

public class InsertionSortDemo {
    static void insertionSort(int[] a) {
        for (int i = 1; i < a.length; i++) {
            int key = a[i], j = i - 1;
            while (j >= 0 && a[j] > key) { a[j + 1] = a[j]; j--; }
            a[j + 1] = key;
        }
    }

    public static void main(String[] args) {
        // Scenario 1: Sorting playing cards in your hand
        System.out.println("=== Scenario 1: Playing Cards in Hand ===");
        int[] cards = {7, 3, 10, 2, 9};
        System.out.println("Before: " + Arrays.toString(cards));
        insertionSort(cards);
        System.out.println("After : " + Arrays.toString(cards));

        // Scenario 2: New order IDs arrive one by one, list stays sorted
        System.out.println("\n=== Scenario 2: Live Order IDs ===");
        int[] incoming = {105, 101, 108, 103};
        int[] sorted = new int[incoming.length];
        int n = 0;
        for (int id : incoming) {
            int j = n - 1;
            while (j >= 0 && sorted[j] > id) { sorted[j + 1] = sorted[j]; j--; }
            sorted[j + 1] = id; n++;
            System.out.println("Order " + id + " arrived -> " + Arrays.toString(Arrays.copyOf(sorted, n)));
        }
    }
}
