import java.util.Arrays;

public class BubbleSortDemo {
    public static void main(String[] args) {
        // Scenario 1: Race finish times - fastest first (show each pass)
        System.out.println("=== Scenario 1: Race Finish Times ===");
        int[] time = {52, 47, 61, 45, 50};
        System.out.println("Before: " + Arrays.toString(time));
        for (int i = 0; i < time.length - 1; i++) {
            for (int j = 0; j < time.length - 1 - i; j++)
                if (time[j] > time[j + 1]) { int t = time[j]; time[j] = time[j + 1]; time[j + 1] = t; }
            System.out.println("Pass " + (i + 1) + ": " + Arrays.toString(time));
        }
        System.out.println("Winner time: " + time[0] + " sec");

        // Scenario 2: Product prices, optimized bubble sort (stops if already sorted)
        System.out.println("\n=== Scenario 2: Product Prices (optimized) ===");
        int[] price = {199, 299, 499, 450, 999};
        System.out.println("Before: " + Arrays.toString(price));
        int passes = 0;
        for (int i = 0; i < price.length - 1; i++) {
            boolean swapped = false;
            for (int j = 0; j < price.length - 1 - i; j++)
                if (price[j] > price[j + 1]) {
                    int t = price[j]; price[j] = price[j + 1]; price[j + 1] = t; swapped = true;
                }
            passes++;
            if (!swapped) break;
        }
        System.out.println("After : " + Arrays.toString(price) + " (passes used: " + passes + ")");
    }
}
