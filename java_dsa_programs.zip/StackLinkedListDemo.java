public class StackLinkedListDemo {
    static class Node { String data; Node next; Node(String d) { data = d; } }

    static class Stack {   // top = head of list, no size limit
        Node top;
        boolean isEmpty() { return top == null; }
        void push(String d) { Node n = new Node(d); n.next = top; top = n; }
        String pop() {
            if (isEmpty()) { System.out.println("Stack Underflow!"); return null; }
            String d = top.data; top = top.next; return d;
        }
        String peek() { return isEmpty() ? null : top.data; }
    }

    public static void main(String[] args) {
        // Scenario 1: Undo in text editor
        System.out.println("=== Scenario 1: Undo in Text Editor ===");
        Stack actions = new Stack();
        actions.push("Typed 'Hello'");
        actions.push("Bold applied");
        actions.push("Pasted image");
        System.out.println("Undo -> " + actions.pop());
        System.out.println("Undo -> " + actions.pop());
        System.out.println("Last action now: " + actions.peek());

        // Scenario 2: Reverse each word's letters / whole string using stack
        System.out.println("\n=== Scenario 2: Reverse a Name ===");
        String name = "DATASTRUCTURE";
        Stack st = new Stack();
        for (char c : name.toCharArray()) st.push(String.valueOf(c));
        StringBuilder sb = new StringBuilder();
        while (!st.isEmpty()) sb.append(st.pop());
        System.out.println(name + " reversed = " + sb);
    }
}
