public class ArrayDemo {
    public static void main(String[] args) {
        // Scenario 1: Student marks - highest, average, search
        System.out.println("=== Scenario 1: Student Marks ===");
        int[] marks = {78, 92, 65, 88, 71};
        int max = marks[0], sum = 0;
        for (int m : marks) { if (m > max) max = m; sum += m; }
        System.out.println("Highest marks: " + max);
        System.out.println("Average marks: " + (double) sum / marks.length);
        int key = 88, pos = -1;
        for (int i = 0; i < marks.length; i++) if (marks[i] == key) { pos = i; break; }
        System.out.println(pos == -1 ? key + " not found" : key + " found at index " + pos);

        // Scenario 2: Weekly temperature - hottest day, days above average
        System.out.println("\n=== Scenario 2: Weekly Temperature ===");
        String[] days = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"};
        int[] temp = {31, 33, 29, 35, 36, 30, 28};
        int hot = 0, total = 0;
        for (int i = 0; i < temp.length; i++) { if (temp[i] > temp[hot]) hot = i; total += temp[i]; }
        double avg = (double) total / temp.length;
        System.out.println("Hottest day: " + days[hot] + " (" + temp[hot] + "C)");
        System.out.printf("Average: %.2fC%n", avg);
        System.out.print("Days above average: ");
        for (int i = 0; i < temp.length; i++) if (temp[i] > avg) System.out.print(days[i] + " ");
        System.out.println();
    }
}
